class exemplo_01{
    
    public static void main(String[] args){

     System.out.print("Ola Mundo! \n\n Esse é meu primeiro programam em Java.");
     
     int idade;
     idade = 15;
     
     System.out.println("idade" + idade);

    //declarar uma variavel tipo String chamada nome:
     String nome;
     nome = "Jose";
     
     System.out.print("nome:" + nome);

     boolean status_aluno;
     status_aluno = true; //true = verdadeiro]
    
     System.out.print("status:" + status);
     //declarar uma variavel do tipo boolean chamada status_aluno

     status_aluno = false;//false = falso

     char periodo;
     periodo = '2';
     
     System.out.print("print:")

    }

}