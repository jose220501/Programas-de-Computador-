
import java.util.Scanner;

class exemplo_operadores{

    public static void main(String[]args ){

        int A;
        int B;

        int soma;
        int subtracao;
        int multiplicacao;
        int divisao;
        double resto_divisao;

        Scanner s = new Scanner(System.in); // Variavel para ler informações do terminal(entrada de dados)

        System.out.println("informe os valores inteiros de:");
        System.out.print("A: ");
        A = s.nextInt();

        System.out.print("B: ");
        B = s.nextInt();

        soma = A + B;
        subtracao = A - B;
        multiplicacao = A * B;
        divisao = A / B;
        resto_divisao = A % B; // 10 % 3 rsultado vai ser 1

        System.out.println("Resultado das operacoes entre A eB:");
        System.out.println("A: " + A + " \nB: " + B);
        System.out.println("soma " + soma);
        System.out.println("subtracao " + subtracao);
        System.out.println("multipicacao " + multiplicacao);
        System.out.println("divisao " + divisao);
        System.out.println("resto_divisao " + resto_divisao);
        System.out.println("Resultado das operacoes Relacionais entre A e B" );
        System.out.println("A: "+ A + "\nB: "+ B);
        System.out.println("A < B: " + ( A<B));

       int ex_inteiro;
       System.out.print("Digite um valor inteiro: ");
       ex_inteiro = s.nextInt();
       System.out.println("ex-inteiro: " + ex_inteiro);
        
       char ex_char;
        System.out.print("Digite um caracter: ");
        ex_char = s.next().charAt(0);
        System.out.println("ex-char: " + ex_char);

        double ex_double;
        System.out.print("Digite um valor decimal: ");
        ex_double = s.nextDouble();
        System.out.println("ex-double: " + ex_double);

        float ex_float;
        System.out.print("Digite um valor real: ");
        ex_float = s.nextFloat();
        System.out.println("ex-float: " + ex_float);

        String ex_string;   
        System.out.print("Digite uma palavra: ");
        ex_string = s.next();
        System.out.println("ex-string: " + ex_string);

        boolean ex_boolean;
        System.out.print("Digite um valor booleano (true ou false): ");
        ex_boolean = s.nextBoolean();
        System.out.println("ex-boolean: " + ex_boolean);

    }

}