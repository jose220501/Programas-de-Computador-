
import java.util.Scanner;


    class exercicio_1{
        
        public static void main(String[] args) {
            
            /* EXERCICIO 1:
             *  Faça um programa que peça o ao usuario qual foi sua nota final no ano letivo
             * se for maior que 6 exiba "aprovado", se for menor que 6 exiba "reprovado".
            */

            double nota_final;
            Scanner s = new Scanner(System.in);

            System.out.print("Qual foi sua nota final no ano letivo? ");
            nota_final = s.nextDouble();
            //menor que 6 e maior que 4
            if(nota_final <6 && nota_final >4);

            {//verdade (true)
                System.out.println("precisa fazer prova substitutiva");
            }else if (nota_final >= 6 )
            {//verdade (true)
                System.out.println("aprovado");
            }else 
            {//falso (false)
                System.out.println("reprovado");
            }
                 
    }         
}
    