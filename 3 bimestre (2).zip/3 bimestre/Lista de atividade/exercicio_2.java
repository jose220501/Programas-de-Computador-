
import java.util.Scanner;


    class exercicio_2{

    public static void main(String[]args ){
      String nome;
      int idade;
      String genero;
      String corfavorita;
      String praticaesporte;
      
      Scanner s = new Scanner(System.in); 

      System.out.print("nome:");
      nome = s.next(); 
      
      System.out.print("idade: ");
      idade = s.nextInt();

      System.out.print("genero: ");
      genero = s.next();

      System.out.print("Cor favorita: ");
      corfavorita = s.next();

      System.out.print("Pratica esporte: ");
      praticaesporte = s.next();

        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Genero: " + genero);
        System.out.println("Cor favorita: " + corfavorita);
        System.out.println("Pratica esporte: " + praticaesporte);

    }
}