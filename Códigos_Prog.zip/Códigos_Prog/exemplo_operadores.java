class exemplo_operadores{
    public static void main(String[]args ){

        int A;
        int B;

        int soma;
        int subtracao;
        int multiplicacao;
        int divisao;
        double resto_divisao;

        A=20;
        B=10;

        soma=A + B;
        subtracao=A - B;
        multiplicacao=A * B;
        divisao=A / B;
        resto_divisao=A % B; // 10 % 3 rsultado vai ser 1

        System.out.println("Resultado das operacoes entre A eB:");
        System.out.println("A: " + A + " \nB: " + B);
        System.out.println("soma" + soma);
        System.out.println("subtracao" + subtracao);
        System.out.println("multipicacao" + multiplicacao);
        System.out.println("divisao" + divisao);
        System.out.println("resto_divisao" + resto_divisao);

        System.out.println("Resultado das operacoes Relacionais entre A e B" );
        System.out.println("A: "+ A + "\nB: "+ B);
        System.out.println("A < B: " + ( A<B));
    }



}